import type { Analytics, Trade } from '@/types';
import type { ChangeEvent } from 'react';
import { BarChart3, CalendarDays, Check, Clock, ClipboardList, Image as ImageIcon, LineChart, MoreHorizontal, Sparkles, Target, TrendingDown, TrendingUp } from 'lucide-react';
import { formatCurrency, shortDayLabel } from '@/analytics';
import { ChartPanel, EquityChart, DailyChart, Insight, MetricCard } from './ui';

const tocItems = [
  { id: 'cumulative-pnl', label: '1. Cumulative PnL' },
  { id: 'result', label: '2. Result' },
  { id: 'psychology', label: '3. Psychology' },
  { id: 'plan-compliance', label: '4. Plan Compliance' },
  { id: 'profit-factor', label: '5. Profit Factor' },
  { id: 'avg-rr', label: '6. Avg RR' },
  { id: 'expectancy', label: '7. Expectancy' },
  { id: 'max-consecutive-loss', label: '8. Max Consecutive Loss' },
  { id: 'max-drawdown', label: '9. Max Drawdown' },
  { id: 'worst-pnl', label: '10. Worst Daily/Weekly PnL' },
  { id: 'best-pnl', label: '11. Best Daily/Weekly PnL' },
  { id: 'trades-by-time', label: '12. Trades by Time' },
  { id: 'win-rate-by-time', label: '13. Win Rate by Time' },
  { id: 'total-pnl-by-time', label: '14. Total PnL by Time' },
  { id: 'avg-pnl-by-time', label: '15. Avg PnL by Time' },
  { id: 'weekdays', label: '16. Weekdays' },
  { id: 'months', label: '17. Months' },
  { id: 'confluences', label: '18. Confluences' },
  { id: 'setup-type', label: '19. Setup Type' },
];

export function StatisticsPage({ analytics, trades, coverImage, onCoverUpload }: {
  analytics: Analytics;
  trades: Trade[];
  coverImage: string;
  onCoverUpload: (e: ChangeEvent<HTMLInputElement>) => void;
}) {
  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  return (
    <>
      <section className="stats-cover" aria-label="Statistics cover">
        {coverImage && <img src={coverImage} alt="Cover" className="cover-img" />}
        <div className="cover-grain"></div>
        <label className="cover-upload-btn">
          <input type="file" accept="image/*" onChange={onCoverUpload} hidden />
          <ImageIcon size={14} /> {coverImage ? 'Change cover' : 'Upload cover image'}
        </label>
      </section>

      <section className="stats-heading">
        <h1>Statistics</h1>
      </section>

      <nav className="toc-grid">
        {tocItems.map((item) => (
          <button key={item.id} onClick={() => scrollTo(item.id)}>{item.label}</button>
        ))}
      </nav>

      <div id="cumulative-pnl" className="metric-grid">
        <MetricCard label="Cumulative PnL" value={formatCurrency(analytics.cumulative)} detail={`${analytics.totalTrades} total trades`} positive={analytics.cumulative >= 0} icon={<TrendingUp size={17} />} />
        <MetricCard label="Win rate" value={`${analytics.winRate.toFixed(1)}%`} detail={`${analytics.wins} winning trades`} positive={analytics.winRate >= 50} icon={<Target size={17} />} />
        <MetricCard label="Avg RR" value={analytics.avgRR.toFixed(2)} detail="Across all trades" positive={analytics.avgRR >= 1} icon={<BarChart3 size={17} />} />
        <MetricCard label="Avg SL" value={formatCurrency(analytics.avgSL)} detail="Average stop loss" positive={false} icon={<TrendingDown size={17} />} />
        <MetricCard label="Avg TP" value={formatCurrency(analytics.avgTP)} detail="Average take profit" positive={true} icon={<TrendingUp size={17} />} />
        <MetricCard label="Expectancy" value={formatCurrency(analytics.expectancy)} detail="Per trade" positive={analytics.expectancy >= 0} icon={<LineChart size={17} />} />
      </div>

      <div className="chart-grid">
        <ChartPanel title="Equity curve" caption="Cumulative PnL over time" icon={<LineChart size={16} />}>
          <EquityChart points={analytics.equity} />
        </ChartPanel>
        <ChartPanel title="Daily PnL" caption="Results grouped by trading day" icon={<BarChart3 size={16} />}>
          <DailyChart points={analytics.daily} />
        </ChartPanel>
      </div>

      <div className="lower-grid">
        <section className="panel insight-panel">
          <div className="panel-head">
            <div className="panel-title"><Sparkles size={16} />Performance notes</div>
          </div>
          <div className="insights">
            <Insight label="Best day" value={analytics.bestDay ? `${shortDayLabel(analytics.bestDay.key)} · ${formatCurrency(analytics.bestDay.value)}` : '—'} positive />
            <Insight label="Worst day" value={analytics.worstDay ? `${shortDayLabel(analytics.worstDay.key)} · ${formatCurrency(analytics.worstDay.value)}` : '—'} />
            <Insight label="Best week" value={analytics.bestWeek ? `${shortDayLabel(analytics.bestWeek.key)} · ${formatCurrency(analytics.bestWeek.value)}` : '—'} positive />
            <Insight label="Worst week" value={analytics.worstWeek ? `${shortDayLabel(analytics.worstWeek.key)} · ${formatCurrency(analytics.worstWeek.value)}` : '—'} />
            <Insight label="Gross loss" value={formatCurrency(analytics.grossLoss)} />
            <Insight label="Gross profit" value={formatCurrency(analytics.grossProfit)} positive />
            <Insight label="Avg win" value={formatCurrency(analytics.avgWin)} positive />
            <Insight label="Avg loss" value={formatCurrency(analytics.avgLoss)} />
          </div>
        </section>
        <section className="panel read-panel">
          <div className="panel-head">
            <div className="panel-title"><ClipboardList size={16} />Journal quality</div>
          </div>
          <div className="quality-row">
            <div className="quality-ring" style={{ '--progress': `${analytics.compliance * 3.6}deg` } as React.CSSProperties}>
              <span>{Math.round(analytics.compliance)}%</span>
            </div>
            <div>
              <strong>Process consistency</strong>
              <p>Every trade is a chance to build a more repeatable process.</p>
            </div>
          </div>
        </section>
      </div>

      <div id="result">
        <BreakdownTable title="Result" icon={<Target size={15} />} headers={['Result', 'Trades', 'Proportion', 'PnL', 'Avg Win', 'Avg Loss', 'Expectancy']}
          rows={analytics.resultBreakdown.map((r) => [
            r.result, String(r.trades), `${r.proportion.toFixed(1)}%`, formatCurrency(r.pnl), formatCurrency(r.avgWin), formatCurrency(r.avgLoss), formatCurrency(r.expectancy)
          ])} toneFn={(row) => row[0] === 'Win' ? 'positive' : row[0] === 'Loss' ? 'negative' : 'neutral'} />
      </div>

      <div id="psychology">
        <BreakdownTable title="Psychology" icon={<Sparkles size={15} />} headers={['Emotion', 'Trades', 'Proportion', 'PnL', 'Avg Win', 'Avg Loss']}
          rows={analytics.psychologyBreakdown.map((p) => [
            p.psych, String(p.trades), `${p.proportion.toFixed(1)}%`, formatCurrency(p.pnl), formatCurrency(p.avgWin), formatCurrency(p.avgLoss)
          ])} toneFn={(row) => row[3].startsWith('-') ? 'negative' : 'positive'} />
      </div>

      <div id="plan-compliance">
        <BreakdownTable title="Plan Compliance" icon={<Check size={15} />} headers={['Compliance', 'Trades', 'PnL', 'Win Rate', 'Avg Win', 'Avg Loss']}
          rows={analytics.complianceBreakdown.map((c) => [
            c.compliance, String(c.trades), formatCurrency(c.pnl), `${c.winRate.toFixed(1)}%`, formatCurrency(c.avgWin), formatCurrency(c.avgLoss)
          ])} toneFn={(row) => row[0] === 'Yes' ? 'positive' : 'negative'} />
      </div>

      <div id="profit-factor" className="metric-grid">
        <MetricCard label="Profit Factor" value={analytics.profitFactor.toFixed(2)} detail={`${formatCurrency(analytics.grossProfit)} profit / ${formatCurrency(analytics.grossLoss)} loss`} positive={analytics.profitFactor >= 1} icon={<BarChart3 size={17} />} />
        <MetricCard label="Avg RR" value={analytics.avgRR.toFixed(2)} detail="Risk-reward ratio" positive={analytics.avgRR >= 1} icon={<Target size={17} />} />
        <MetricCard label="Expectancy ($USD)" value={formatCurrency(analytics.expectancy)} detail="Expected PnL per trade" positive={analytics.expectancy >= 0} icon={<LineChart size={17} />} />
      </div>

      <div id="max-consecutive-loss" className="metric-grid">
        <MetricCard label="Max Consecutive Losses" value={String(analytics.maxLosses)} detail="Longest losing streak" positive={false} icon={<TrendingDown size={17} />} />
      </div>

      <div id="max-drawdown" className="metric-grid">
        <MetricCard label="Max Drawdown" value={formatCurrency(analytics.maxDrawdown)} detail={analytics.maxDrawdownPct ? `${analytics.maxDrawdownPct.toFixed(1)}% from peak` : 'No drawdown'} positive={false} icon={<TrendingDown size={17} />} />
      </div>

      <div id="worst-pnl" className="metric-grid">
        <MetricCard label="Worst Day PnL" value={analytics.worstDay ? formatCurrency(analytics.worstDay.value) : '—'} detail={analytics.worstDay ? shortDayLabel(analytics.worstDay.key) : ''} positive={false} icon={<TrendingDown size={17} />} />
        <MetricCard label="Worst Week PnL" value={analytics.worstWeek ? formatCurrency(analytics.worstWeek.value) : '—'} detail={analytics.worstWeek ? shortDayLabel(analytics.worstWeek.key) : ''} positive={false} icon={<TrendingDown size={17} />} />
      </div>

      <div id="best-pnl" className="metric-grid">
        <MetricCard label="Best Day PnL" value={analytics.bestDay ? formatCurrency(analytics.bestDay.value) : '—'} detail={analytics.bestDay ? shortDayLabel(analytics.bestDay.key) : ''} positive={true} icon={<TrendingUp size={17} />} />
        <MetricCard label="Best Week PnL" value={analytics.bestWeek ? formatCurrency(analytics.bestWeek.value) : '—'} detail={analytics.bestWeek ? shortDayLabel(analytics.bestWeek.key) : ''} positive={true} icon={<TrendingUp size={17} />} />
      </div>

      <div id="trades-by-time">
        <BreakdownTable title="Trades by Time" icon={<Clock size={15} />} headers={['Hour', 'Trades', 'PnL', 'Win Rate', 'Avg Win', 'Avg Loss']}
          rows={analytics.hourBreakdown.map((h) => [
            h.hour, String(h.trades), formatCurrency(h.pnl), `${h.winRate.toFixed(1)}%`, formatCurrency(h.avgWin), formatCurrency(h.avgLoss)
          ])} toneFn={(row) => row[2].startsWith('-') ? 'negative' : 'positive'} />
      </div>

      <div id="win-rate-by-time">
        <BreakdownTable title="Win Rate by Time" icon={<Clock size={15} />} headers={['Hour', 'Trades', 'Win Rate', 'Avg Win', 'Avg Loss']}
          rows={analytics.hourBreakdown.map((h) => [
            h.hour, String(h.trades), `${h.winRate.toFixed(1)}%`, formatCurrency(h.avgWin), formatCurrency(h.avgLoss)
          ])} toneFn={() => 'neutral'} />
      </div>

      <div id="total-pnl-by-time">
        <BreakdownTable title="Total PnL by Time" icon={<Clock size={15} />} headers={['Hour', 'Trades', 'Total PnL', 'Avg Win', 'Avg Loss']}
          rows={analytics.hourBreakdown.map((h) => [
            h.hour, String(h.trades), formatCurrency(h.pnl), formatCurrency(h.avgWin), formatCurrency(h.avgLoss)
          ])} toneFn={(row) => row[2].startsWith('-') ? 'negative' : 'positive'} />
      </div>

      <div id="avg-pnl-by-time">
        <BreakdownTable title="Avg PnL by Time" icon={<Clock size={15} />} headers={['Hour', 'Trades', 'Avg PnL', 'Win Rate']}
          rows={analytics.hourBreakdown.map((h) => [
            h.hour, String(h.trades), formatCurrency(h.avgPnl), `${h.winRate.toFixed(1)}%`
          ])} toneFn={(row) => row[2].startsWith('-') ? 'negative' : 'positive'} />
      </div>

      <div id="weekdays">
        <BreakdownTable title="Weekdays" icon={<CalendarDays size={15} />} headers={['Weekday', 'Trades', 'PnL', 'Win Rate', 'Avg Win', 'Avg Loss']}
          rows={analytics.weekdayBreakdown.map((w) => [
            w.weekday, String(w.trades), formatCurrency(w.pnl), `${w.winRate.toFixed(1)}%`, formatCurrency(w.avgWin), formatCurrency(w.avgLoss)
          ])} toneFn={(row) => row[2].startsWith('-') ? 'negative' : 'positive'} />
      </div>

      <div id="months">
        <BreakdownTable title="Months" icon={<CalendarDays size={15} />} headers={['Month', 'Trades', 'PnL', 'Win Rate', 'Avg Win', 'Avg Loss']}
          rows={analytics.monthBreakdown.map((m) => [
            m.month, String(m.trades), formatCurrency(m.pnl), `${m.winRate.toFixed(1)}%`, formatCurrency(m.avgWin), formatCurrency(m.avgLoss)
          ])} toneFn={(row) => row[2].startsWith('-') ? 'negative' : 'positive'} />
      </div>

      <div id="confluences">
        <BreakdownTable title="Confluences" icon={<BarChart3 size={15} />} headers={['Confluence', 'Trades', 'PnL', 'Win Rate', 'Avg Win', 'Avg Loss']}
          rows={analytics.confluenceBreakdown.map((c) => [
            c.confluence, String(c.trades), formatCurrency(c.pnl), `${c.winRate.toFixed(1)}%`, formatCurrency(c.avgWin), formatCurrency(c.avgLoss)
          ])} toneFn={(row) => row[2].startsWith('-') ? 'negative' : 'positive'} />
      </div>

      <div id="setup-type">
        <BreakdownTable title="Setup Type" icon={<Target size={15} />} headers={['Setup Type', 'Trades', 'PnL', 'Win Rate', 'Avg Win', 'Avg Loss']}
          rows={analytics.setupTypeBreakdown.map((s) => [
            s.setupType, String(s.trades), formatCurrency(s.pnl), `${s.winRate.toFixed(1)}%`, formatCurrency(s.avgWin), formatCurrency(s.avgLoss)
          ])} toneFn={(row) => row[2].startsWith('-') ? 'negative' : 'positive'} />
      </div>
    </>
  );
}

function BreakdownTable({ title, icon, headers, rows, toneFn }: { title: string; icon: React.ReactNode; headers: string[]; rows: string[][]; toneFn: (row: string[]) => string }) {
  return (
    <section className="panel breakdown-panel">
      <div className="panel-head">
        <div>
          <div className="panel-title">{icon}{title}</div>
          <div className="panel-caption">Breakdown by {title.toLowerCase()}</div>
        </div>
        <button className="icon-button"><MoreHorizontal size={17} /></button>
      </div>
      <div className="table-scroll">
        <table>
          <thead>
            <tr>
              {headers.map((h, i) => <th key={h} className={i === 0 ? 'first-col' : ''}>{h}</th>)}
            </tr>
          </thead>
          <tbody>
            {rows.map((row, ri) => (
              <tr key={ri}>
                {row.map((cell, ci) => (
                  <td key={ci} className={ci === 0 ? 'first-col' : ''}>
                    {ci === 0 ? <span className={`breakdown-label ${toneFn(row)}`}>{cell}</span> : <span className={ci === 3 || ci === 2 ? toneFn(row) : ''}>{cell}</span>}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}
