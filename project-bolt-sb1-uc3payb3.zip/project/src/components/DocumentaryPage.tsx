import { useMemo, useState } from 'react';
import { Plus, Pencil, Trash2, Search, Image as ImageIcon, Table as TableIcon, CalendarDays, GalleryHorizontalEnd, Filter } from 'lucide-react';
import type { Trade } from '@/lib/supabase';
import type { UseJournalData } from '@/hooks/useJournalData';
import { computeMetrics, getWeekKey, getCurrentWeekKey } from '@/lib/metrics';
import { TradeForm } from './TradeForm';
import { TradeImage } from './TradeImage';

type DocumentaryPageProps = {
  data: UseJournalData;
};

type ViewTab = 'full_log' | 'full_gallery' | 'weekly_log' | 'weekly_gallery' | 'loss_log' | 'win_log';

const VIEW_TABS: { id: ViewTab; label: string; icon: typeof TableIcon }[] = [
  { id: 'full_log', label: 'Full Log', icon: TableIcon },
  { id: 'full_gallery', label: 'Full Gallery', icon: GalleryHorizontalEnd },
  { id: 'weekly_log', label: 'Weekly Log', icon: CalendarDays },
  { id: 'weekly_gallery', label: 'Weekly Gallery', icon: ImageIcon },
  { id: 'loss_log', label: 'Loss Log', icon: TableIcon },
  { id: 'win_log', label: 'Win Log', icon: TableIcon },
];

export function DocumentaryPage({ data }: DocumentaryPageProps) {
  const { trades, addTrade, updateTrade, deleteTrade } = data;
  const [view, setView] = useState<ViewTab>('full_log');
  const [showForm, setShowForm] = useState(false);
  const [editingTrade, setEditingTrade] = useState<Trade | null>(null);
  const [search, setSearch] = useState('');
  const [breakevenFilter, setBreakevenFilter] = useState<'all' | 'include' | 'exclude'>('all');

  const metrics = useMemo(() => computeMetrics(trades), [trades]);

  const filteredTrades = useMemo(() => {
    let result = [...trades].sort((a, b) => {
      const da = new Date(`${a.date}T${a.time || '00:00'}`);
      const db = new Date(`${b.date}T${b.time || '00:00'}`);
      return db.getTime() - da.getTime();
    });

    if (view === 'loss_log') {
      result = result.filter((t) => t.result === 'loss');
      if (breakevenFilter === 'exclude') result = result.filter((t) => t.result !== 'breakeven');
    } else if (view === 'win_log') {
      result = result.filter((t) => t.result === 'win');
      if (breakevenFilter === 'exclude') result = result.filter((t) => t.result !== 'breakeven');
    }

    if (search) {
      const q = search.toLowerCase();
      result = result.filter(
        (t) =>
          t.symbol.toLowerCase().includes(q) ||
          t.setup_type.toLowerCase().includes(q) ||
          t.psychology.toLowerCase().includes(q) ||
          t.notes.toLowerCase().includes(q) ||
          t.confluences.some((c) => c.toLowerCase().includes(q))
      );
    }

    return result;
  }, [trades, view, search, breakevenFilter]);

  const weeklyGroups = useMemo(() => {
    const currentWeek = getCurrentWeekKey();
    const groups: { key: string; trades: Trade[]; isCurrent: boolean }[] = [];
    const weekMap = new Map<string, Trade[]>();
    for (const t of filteredTrades) {
      const wk = getWeekKey(t.date);
      if (!weekMap.has(wk)) weekMap.set(wk, []);
      weekMap.get(wk)!.push(t);
    }
    for (const [wk, ts] of Array.from(weekMap.entries()).sort((a, b) => b[0].localeCompare(a[0]))) {
      groups.push({ key: wk, trades: ts, isCurrent: wk === currentWeek });
    }
    return groups;
  }, [filteredTrades]);

  const handleSave = async (trade: Omit<Trade, 'id' | 'user_id' | 'created_at' | 'updated_at'>) => {
    if (editingTrade) {
      await updateTrade(editingTrade.id, trade);
    } else {
      await addTrade(trade);
    }
  };

  const handleDelete = async (id: string) => {
    await deleteTrade(id);
  };

  const summaryCards = [
    { label: 'Total Trades', value: metrics.totalTrades, color: 'text-gray-900 dark:text-white' },
    { label: 'Win Rate', value: `${metrics.winRate.toFixed(1)}%`, color: metrics.winRate >= 50 ? 'text-blue-500 dark:text-blue-400' : 'text-amber-500 dark:text-amber-400' },
    { label: 'Total PnL', value: `$${metrics.totalPnL.toFixed(2)}`, color: metrics.totalPnL >= 0 ? 'text-blue-500 dark:text-blue-400' : 'text-red-500 dark:text-red-400' },
    { label: 'Wins', value: metrics.wins, color: 'text-blue-500 dark:text-blue-400' },
    { label: 'Losses', value: metrics.losses, color: 'text-red-500 dark:text-red-400' },
    { label: 'Breakeven', value: metrics.breakeven, color: 'text-gray-500 dark:text-gray-400' },
    { label: 'Avg SL (points)', value: metrics.avgSL.toFixed(2), color: 'text-gray-900 dark:text-white' },
    { label: 'Avg TP (points)', value: metrics.avgTP.toFixed(2), color: 'text-gray-900 dark:text-white' },
  ];

  return (
    <div className="space-y-6">
      {/* Summary cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-3">
        {summaryCards.map((card) => (
          <div key={card.label} className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-xl p-3">
            <div className="text-xs text-gray-500 dark:text-gray-400 mb-1">{card.label}</div>
            <div className={`text-lg font-semibold ${card.color}`}>{card.value}</div>
          </div>
        ))}
      </div>

      {/* View switcher */}
      <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between">
        <div className="flex flex-wrap gap-1 p-1 bg-gray-100 dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-lg">
          {VIEW_TABS.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setView(tab.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-all ${
                  view === tab.id ? 'bg-blue-600 text-white' : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white hover:bg-gray-200 dark:hover:bg-gray-800'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                {tab.label}
              </button>
            );
          })}
        </div>

        <div className="flex gap-2 w-full sm:w-auto">
          {(view === 'loss_log' || view === 'win_log') && (
            <select
              value={breakevenFilter}
              onChange={(e) => setBreakevenFilter(e.target.value as 'all' | 'include' | 'exclude')}
              className="px-3 py-1.5 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-lg text-sm text-gray-900 dark:text-white focus:outline-none focus:border-blue-500"
            >
              <option value="all">Include Breakeven</option>
              <option value="exclude">Exclude Breakeven</option>
            </select>
          )}
          <div className="relative flex-1 sm:flex-none">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search trades..."
              className="pl-8 pr-3 py-1.5 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-lg text-sm text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:border-blue-500 w-full sm:w-56"
            />
          </div>
          <button
            onClick={() => { setEditingTrade(null); setShowForm(true); }}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white text-sm font-medium rounded-lg transition-colors whitespace-nowrap"
          >
            <Plus className="w-4 h-4" /> New Trade
          </button>
        </div>
      </div>

      {/* Content */}
      {(view === 'full_log' || view === 'loss_log' || view === 'win_log') && (
        <TradeTable trades={filteredTrades} onEdit={(t) => { setEditingTrade(t); setShowForm(true); }} onDelete={handleDelete} />
      )}

      {view === 'full_gallery' && <TradeGallery trades={filteredTrades} onEdit={(t) => { setEditingTrade(t); setShowForm(true); }} />}

      {(view === 'weekly_log' || view === 'weekly_gallery') && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {weeklyGroups.map((group) => (
            <div key={group.key} className={`rounded-xl border ${group.isCurrent ? 'border-blue-500 dark:border-blue-700' : 'border-gray-200 dark:border-gray-800'} bg-white/50 dark:bg-gray-900/50 overflow-hidden`}>
              <div className={`px-4 py-2.5 text-sm font-medium ${group.isCurrent ? 'bg-blue-50 dark:bg-blue-950/50 text-blue-700 dark:text-blue-300' : 'bg-gray-50 dark:bg-gray-900 text-gray-700 dark:text-gray-300'} flex items-center gap-2`}>
                <CalendarDays className="w-4 h-4" />
                {group.key}
                {group.isCurrent && <span className="text-xs px-1.5 py-0.5 bg-blue-600 text-white rounded">Current</span>}
              </div>
              {view === 'weekly_log' ? (
                <TradeTable trades={group.trades} onEdit={(t) => { setEditingTrade(t); setShowForm(true); }} onDelete={handleDelete} compact />
              ) : (
                <TradeGallery trades={group.trades} onEdit={(t) => { setEditingTrade(t); setShowForm(true); }} compact />
              )}
            </div>
          ))}
        </div>
      )}

      {filteredTrades.length === 0 && (
        <div className="flex flex-col items-center justify-center py-20 text-gray-400 dark:text-gray-500">
          <Filter className="w-10 h-10 mb-3 opacity-50" />
          <p className="text-sm">No trades found. {view === 'full_log' && 'Add your first trade to get started.'}</p>
        </div>
      )}

      {showForm && (
        <TradeForm trade={editingTrade} onClose={() => setShowForm(false)} onSave={handleSave} />
      )}
    </div>
  );
}

function TradeTable({ trades, onEdit, onDelete, compact }: { trades: Trade[]; onEdit: (t: Trade) => void; onDelete: (id: string) => Promise<void>; compact?: boolean }) {
  if (trades.length === 0) return <div className="p-8 text-center text-sm text-gray-400 dark:text-gray-500">No trades in this view.</div>;

  return (
    <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-xl overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-gray-200 dark:border-gray-800 text-gray-500 dark:text-gray-400 text-xs">
            <th className="text-left px-3 py-2.5 font-medium">Date</th>
            <th className="text-left px-3 py-2.5 font-medium">Symbol</th>
            <th className="text-left px-3 py-2.5 font-medium">Dir</th>
            <th className="text-left px-3 py-2.5 font-medium">Setup</th>
            <th className="text-left px-3 py-2.5 font-medium">Result</th>
            <th className="text-right px-3 py-2.5 font-medium">PnL</th>
            {!compact && <th className="text-right px-3 py-2.5 font-medium">R</th>}
            {!compact && <th className="text-right px-3 py-2.5 font-medium">SL</th>}
            {!compact && <th className="text-right px-3 py-2.5 font-medium">TP</th>}
            {!compact && <th className="text-left px-3 py-2.5 font-medium">Psychology</th>}
            <th className="text-center px-3 py-2.5 font-medium">Actions</th>
          </tr>
        </thead>
        <tbody>
          {trades.map((t) => (
            <tr key={t.id} className="border-b border-gray-100 dark:border-gray-800/50 hover:bg-gray-50 dark:hover:bg-gray-800/30 transition-colors">
              <td className="px-3 py-2 text-gray-700 dark:text-gray-300 whitespace-nowrap">{t.date}{t.time && <span className="text-gray-400 dark:text-gray-500 text-xs ml-1">{t.time}</span>}</td>
              <td className="px-3 py-2 text-gray-900 dark:text-white font-medium">{t.symbol || '-'}</td>
              <td className="px-3 py-2">
                <span className={`text-xs px-1.5 py-0.5 rounded ${t.direction === 'long' ? 'bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-400' : 'bg-red-100 dark:bg-red-950 text-red-700 dark:text-red-400'}`}>
                  {t.direction === 'long' ? 'L' : 'S'}
                </span>
              </td>
              <td className="px-3 py-2 text-gray-700 dark:text-gray-300">{t.setup_type || '-'}</td>
              <td className="px-3 py-2">
                <span className={`text-xs px-1.5 py-0.5 rounded ${
                  t.result === 'win' ? 'bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-400' :
                  t.result === 'loss' ? 'bg-red-100 dark:bg-red-950 text-red-700 dark:text-red-400' :
                  'bg-gray-100 dark:bg-gray-800 text-gray-500 dark:text-gray-400'
                }`}>
                  {t.result}
                </span>
              </td>
              <td className={`px-3 py-2 text-right font-medium ${t.pnl >= 0 ? 'text-blue-500 dark:text-blue-400' : 'text-red-500 dark:text-red-400'}`}>
                ${t.pnl.toFixed(2)}
              </td>
              {!compact && <td className="px-3 py-2 text-right text-gray-500 dark:text-gray-400">{t.r_multiple != null ? t.r_multiple.toFixed(2) : '-'}</td>}
              {!compact && <td className="px-3 py-2 text-right text-gray-500 dark:text-gray-400">{t.sl_points != null ? t.sl_points.toFixed(2) : '-'}</td>}
              {!compact && <td className="px-3 py-2 text-right text-gray-500 dark:text-gray-400">{t.tp_points != null ? t.tp_points.toFixed(2) : '-'}</td>}
              {!compact && <td className="px-3 py-2 text-gray-700 dark:text-gray-300 text-xs">{t.psychology || '-'}</td>}
              <td className="px-3 py-2">
                <div className="flex items-center justify-center gap-1">
                  <button onClick={() => onEdit(t)} className="p-1.5 text-gray-400 hover:text-blue-500 dark:hover:text-blue-400 transition-colors">
                    <Pencil className="w-3.5 h-3.5" />
                  </button>
                  <button onClick={() => onDelete(t.id)} className="p-1.5 text-gray-400 hover:text-red-500 dark:hover:text-red-400 transition-colors">
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function TradeGallery({ trades, onEdit, compact }: { trades: Trade[]; onEdit: (t: Trade) => void; compact?: boolean }) {
  if (trades.length === 0) return <div className="p-8 text-center text-sm text-gray-400 dark:text-gray-500">No trades in this view.</div>;

  return (
    <div className={`grid gap-3 ${compact ? 'grid-cols-1 sm:grid-cols-2' : 'grid-cols-2 md:grid-cols-3 lg:grid-cols-4'}`}>
      {trades.map((t) => (
        <div key={t.id} className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-xl overflow-hidden group cursor-pointer hover:border-gray-300 dark:hover:border-gray-700 transition-colors" onClick={() => onEdit(t)}>
          <div className="aspect-video bg-gray-100 dark:bg-gray-800 flex items-center justify-center overflow-hidden">
            {t.image_path ? (
              <TradeImage path={t.image_path} alt={t.symbol} />
            ) : (
              <ImageIcon className="w-8 h-8 text-gray-300 dark:text-gray-600" />
            )}
          </div>
          <div className="p-3 space-y-1">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-gray-900 dark:text-white">{t.symbol || 'Unknown'}</span>
              <span className={`text-xs px-1.5 py-0.5 rounded ${t.result === 'win' ? 'bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-400' : t.result === 'loss' ? 'bg-red-100 dark:bg-red-950 text-red-700 dark:text-red-400' : 'bg-gray-100 dark:bg-gray-800 text-gray-500 dark:text-gray-400'}`}>
                {t.result}
              </span>
            </div>
            <div className="flex items-center justify-between text-xs text-gray-500 dark:text-gray-400">
              <span>{t.date}</span>
              <span className={t.pnl >= 0 ? 'text-blue-500 dark:text-blue-400' : 'text-red-500 dark:text-red-400'}>${t.pnl.toFixed(2)}</span>
            </div>
            {t.setup_type && <div className="text-xs text-gray-400 dark:text-gray-500 truncate">{t.setup_type}</div>}
          </div>
        </div>
      ))}
    </div>
  );
}
