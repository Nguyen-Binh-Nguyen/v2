import type { Trade } from './supabase';

export type Metrics = {
  totalTrades: number;
  wins: number;
  losses: number;
  breakeven: number;
  winRate: number;
  totalPnL: number;
  avgPnL: number;
  grossProfit: number;
  grossLoss: number;
  profitFactor: number;
  avgRR: number;
  expectancy: number;
  avgSL: number;
  avgTP: number;
  compliant: number;
  nonCompliant: number;
  maxConsecutiveLoss: number;
  maxDrawdown: number;
  peakPnL: number;
  troughPnL: number;
  worstDailyPnL: number;
  bestDailyPnL: number;
  worstWeeklyPnL: number;
  bestWeeklyPnL: number;
  cumulativePnL: { date: string; value: number }[];
  tradesByTime: { hour: string; count: number }[];
  winRateByTime: { hour: string; winRate: number }[];
  totalPnLByTime: { hour: string; pnl: number }[];
  avgPnLByTime: { hour: string; avgPnL: number }[];
  byWeekday: { day: string; trades: number; pnl: number; winRate: number }[];
  byMonth: { month: string; trades: number; pnl: number; winRate: number }[];
  bySetup: { type: string; trades: number; pnl: number; winRate: number }[];
  byConfluence: { confluence: string; trades: number; pnl: number; winRate: number }[];
  byPsychology: { psychology: string; trades: number; pnl: number; winRate: number }[];
  byPlanCompliance: { compliant: boolean; trades: number; pnl: number }[];
  byResult: { result: string; count: number; pnl: number }[];
  byDirection: { direction: string; trades: number; pnl: number }[];
};

const WEEKDAY_NAMES = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const MONTH_NAMES = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

function getISOWeek(date: Date): string {
  const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  const dayNum = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  const weekNum = Math.ceil(((d.getTime() - yearStart.getTime()) / 86400000 + 1) / 7);
  return `${d.getUTCFullYear()}-W${String(weekNum).padStart(2, '0')}`;
}

export function computeMetrics(trades: Trade[]): Metrics {
  const sorted = [...trades].sort((a, b) => {
    const da = new Date(`${a.date}T${a.time || '00:00'}`);
    const db = new Date(`${b.date}T${b.time || '00:00'}`);
    return da.getTime() - db.getTime();
  });

  const totalTrades = sorted.length;
  const wins = sorted.filter((t) => t.result === 'win').length;
  const losses = sorted.filter((t) => t.result === 'loss').length;
  const breakeven = sorted.filter((t) => t.result === 'breakeven').length;
  const winRate = totalTrades > 0 ? (wins / totalTrades) * 100 : 0;
  const totalPnL = sorted.reduce((s, t) => s + (t.pnl || 0), 0);
  const avgPnL = totalTrades > 0 ? totalPnL / totalTrades : 0;
  const grossProfit = sorted.filter((t) => t.pnl > 0).reduce((s, t) => s + t.pnl, 0);
  const grossLoss = Math.abs(sorted.filter((t) => t.pnl < 0).reduce((s, t) => s + t.pnl, 0));
  const profitFactor = grossLoss > 0 ? grossProfit / grossLoss : grossProfit > 0 ? Infinity : 0;

  const rrValues = sorted.filter((t) => t.r_multiple != null).map((t) => t.r_multiple!);
  const avgRR = rrValues.length > 0 ? rrValues.reduce((s, v) => s + v, 0) / rrValues.length : 0;
  const expectancy = avgPnL;

  const slValues = sorted.filter((t) => t.sl_points != null).map((t) => t.sl_points!);
  const avgSL = slValues.length > 0 ? slValues.reduce((s, v) => s + v, 0) / slValues.length : 0;
  const tpValues = sorted.filter((t) => t.tp_points != null).map((t) => t.tp_points!);
  const avgTP = tpValues.length > 0 ? tpValues.reduce((s, v) => s + v, 0) / tpValues.length : 0;

  const compliant = sorted.filter((t) => t.plan_compliance).length;
  const nonCompliant = totalTrades - compliant;

  // Max consecutive loss
  let maxConsecutiveLoss = 0;
  let currentStreak = 0;
  for (const t of sorted) {
    if (t.result === 'loss') {
      currentStreak++;
      maxConsecutiveLoss = Math.max(maxConsecutiveLoss, currentStreak);
    } else {
      currentStreak = 0;
    }
  }

  // Cumulative PnL + drawdown
  let cumulative = 0;
  const cumulativePnL: { date: string; value: number }[] = [];
  let peak = 0;
  let trough = 0;
  let maxDrawdown = 0;
  for (const t of sorted) {
    cumulative += t.pnl || 0;
    cumulativePnL.push({ date: t.date, value: cumulative });
    peak = Math.max(peak, cumulative);
    trough = Math.min(trough, cumulative);
    const dd = peak - cumulative;
    maxDrawdown = Math.max(maxDrawdown, dd);
  }

  // Daily PnL
  const dailyMap = new Map<string, number>();
  for (const t of sorted) {
    dailyMap.set(t.date, (dailyMap.get(t.date) || 0) + (t.pnl || 0));
  }
  const dailyValues = Array.from(dailyMap.values());
  const worstDailyPnL = dailyValues.length > 0 ? Math.min(...dailyValues) : 0;
  const bestDailyPnL = dailyValues.length > 0 ? Math.max(...dailyValues) : 0;

  // Weekly PnL
  const weeklyMap = new Map<string, number>();
  for (const t of sorted) {
    const d = new Date(t.date);
    const week = getISOWeek(d);
    weeklyMap.set(week, (weeklyMap.get(week) || 0) + (t.pnl || 0));
  }
  const weeklyValues = Array.from(weeklyMap.values());
  const worstWeeklyPnL = weeklyValues.length > 0 ? Math.min(...weeklyValues) : 0;
  const bestWeeklyPnL = weeklyValues.length > 0 ? Math.max(...weeklyValues) : 0;

  // Time-based metrics
  const HOURS = Array.from({ length: 24 }, (_, i) => `${String(i).padStart(2, '0')}:00`);
  const timeCount = new Map<string, number>();
  const timeWinCount = new Map<string, number>();
  const timePnL = new Map<string, number>();
  for (const h of HOURS) {
    timeCount.set(h, 0);
    timeWinCount.set(h, 0);
    timePnL.set(h, 0);
  }
  for (const t of sorted) {
    if (!t.time) continue;
    const hour = t.time.substring(0, 2) + ':00';
    timeCount.set(hour, (timeCount.get(hour) || 0) + 1);
    if (t.result === 'win') timeWinCount.set(hour, (timeWinCount.get(hour) || 0) + 1);
    timePnL.set(hour, (timePnL.get(hour) || 0) + (t.pnl || 0));
  }
  const tradesByTime = HOURS.map((h) => ({ hour: h, count: timeCount.get(h) || 0 })).filter((x) => x.count > 0);
  const winRateByTime = HOURS.map((h) => {
    const c = timeCount.get(h) || 0;
    const w = timeWinCount.get(h) || 0;
    return { hour: h, winRate: c > 0 ? (w / c) * 100 : 0 };
  }).filter((x) => timeCount.get(x.hour)! > 0);
  const totalPnLByTime = HOURS.map((h) => ({ hour: h, pnl: timePnL.get(h) || 0 })).filter((x) => x.pnl !== 0);
  const avgPnLByTime = HOURS.map((h) => {
    const c = timeCount.get(h) || 0;
    const p = timePnL.get(h) || 0;
    return { hour: h, avgPnL: c > 0 ? p / c : 0 };
  }).filter((x) => timeCount.get(x.hour)! > 0);

  // By weekday
  const weekdayMap = new Map<string, { trades: number; pnl: number; wins: number }>();
  for (let i = 0; i < 7; i++) {
    weekdayMap.set(WEEKDAY_NAMES[i], { trades: 0, pnl: 0, wins: 0 });
  }
  for (const t of sorted) {
    const d = new Date(t.date);
    const day = WEEKDAY_NAMES[d.getDay()];
    const entry = weekdayMap.get(day)!;
    entry.trades++;
    entry.pnl += t.pnl || 0;
    if (t.result === 'win') entry.wins++;
  }
  const byWeekday = WEEKDAY_NAMES.map((day) => {
    const e = weekdayMap.get(day)!;
    return { day, trades: e.trades, pnl: e.pnl, winRate: e.trades > 0 ? (e.wins / e.trades) * 100 : 0 };
  }).filter((x) => x.trades > 0);

  // By month
  const monthMap = new Map<string, { trades: number; pnl: number; wins: number }>();
  for (const t of sorted) {
    const d = new Date(t.date);
    const key = `${d.getFullYear()}-${MONTH_NAMES[d.getMonth()]}`;
    const entry = monthMap.get(key) || { trades: 0, pnl: 0, wins: 0 };
    entry.trades++;
    entry.pnl += t.pnl || 0;
    if (t.result === 'win') entry.wins++;
    monthMap.set(key, entry);
  }
  const byMonth = Array.from(monthMap.entries())
    .sort((a, b) => a[0].localeCompare(b[0]))
    .map(([month, e]) => ({ month, trades: e.trades, pnl: e.pnl, winRate: e.trades > 0 ? (e.wins / e.trades) * 100 : 0 }));

  // By setup type
  const setupMap = new Map<string, { trades: number; pnl: number; wins: number }>();
  for (const t of sorted) {
    const key = t.setup_type || 'Unknown';
    const entry = setupMap.get(key) || { trades: 0, pnl: 0, wins: 0 };
    entry.trades++;
    entry.pnl += t.pnl || 0;
    if (t.result === 'win') entry.wins++;
    setupMap.set(key, entry);
  }
  const bySetup = Array.from(setupMap.entries())
    .sort((a, b) => b[1].pnl - a[1].pnl)
    .map(([type, e]) => ({ type, trades: e.trades, pnl: e.pnl, winRate: e.trades > 0 ? (e.wins / e.trades) * 100 : 0 }));

  // By confluence
  const confluenceMap = new Map<string, { trades: number; pnl: number; wins: number }>();
  for (const t of sorted) {
    for (const c of t.confluences || []) {
      const key = c.trim();
      if (!key) continue;
      const entry = confluenceMap.get(key) || { trades: 0, pnl: 0, wins: 0 };
      entry.trades++;
      entry.pnl += t.pnl || 0;
      if (t.result === 'win') entry.wins++;
      confluenceMap.set(key, entry);
    }
  }
  const byConfluence = Array.from(confluenceMap.entries())
    .sort((a, b) => b[1].pnl - a[1].pnl)
    .map(([confluence, e]) => ({ confluence, trades: e.trades, pnl: e.pnl, winRate: e.trades > 0 ? (e.wins / e.trades) * 100 : 0 }));

  // By psychology
  const psychMap = new Map<string, { trades: number; pnl: number; wins: number }>();
  for (const t of sorted) {
    const key = t.psychology || 'Unknown';
    const entry = psychMap.get(key) || { trades: 0, pnl: 0, wins: 0 };
    entry.trades++;
    entry.pnl += t.pnl || 0;
    if (t.result === 'win') entry.wins++;
    psychMap.set(key, entry);
  }
  const byPsychology = Array.from(psychMap.entries())
    .sort((a, b) => b[1].pnl - a[1].pnl)
    .map(([psychology, e]) => ({ psychology, trades: e.trades, pnl: e.pnl, winRate: e.trades > 0 ? (e.wins / e.trades) * 100 : 0 }));

  // Plan compliance
  const byPlanCompliance = [
    { compliant: true, trades: compliant, pnl: sorted.filter((t) => t.plan_compliance).reduce((s, t) => s + (t.pnl || 0), 0) },
    { compliant: false, trades: nonCompliant, pnl: sorted.filter((t) => !t.plan_compliance).reduce((s, t) => s + (t.pnl || 0), 0) },
  ];

  // By result
  const byResult = [
    { result: 'win', count: wins, pnl: sorted.filter((t) => t.result === 'win').reduce((s, t) => s + (t.pnl || 0), 0) },
    { result: 'loss', count: losses, pnl: sorted.filter((t) => t.result === 'loss').reduce((s, t) => s + (t.pnl || 0), 0) },
    { result: 'breakeven', count: breakeven, pnl: sorted.filter((t) => t.result === 'breakeven').reduce((s, t) => s + (t.pnl || 0), 0) },
  ];

  // By direction
  const longTrades = sorted.filter((t) => t.direction === 'long');
  const shortTrades = sorted.filter((t) => t.direction === 'short');
  const byDirection = [
    { direction: 'long', trades: longTrades.length, pnl: longTrades.reduce((s, t) => s + (t.pnl || 0), 0) },
    { direction: 'short', trades: shortTrades.length, pnl: shortTrades.reduce((s, t) => s + (t.pnl || 0), 0) },
  ];

  return {
    totalTrades,
    wins,
    losses,
    breakeven,
    winRate,
    totalPnL,
    avgPnL,
    grossProfit,
    grossLoss,
    profitFactor,
    avgRR,
    expectancy,
    avgSL,
    avgTP,
    compliant,
    nonCompliant,
    maxConsecutiveLoss,
    maxDrawdown,
    peakPnL: peak,
    troughPnL: trough,
    worstDailyPnL,
    bestDailyPnL,
    worstWeeklyPnL,
    bestWeeklyPnL,
    cumulativePnL,
    tradesByTime,
    winRateByTime,
    totalPnLByTime,
    avgPnLByTime,
    byWeekday,
    byMonth,
    bySetup,
    byConfluence,
    byPsychology,
    byPlanCompliance,
    byResult,
    byDirection,
  };
}

export function getWeekKey(dateStr: string): string {
  return getISOWeek(new Date(dateStr));
}

export function getCurrentWeekKey(): string {
  return getISOWeek(new Date());
}

export { WEEKDAY_NAMES, MONTH_NAMES };
